from django.shortcuts import render, redirect
import logging
from django.http.response import HttpResponse
from django.template import loader
from django.views.generic.base import View

class PopulationMainView( View ):
    def get(self, request):
        template = loader.get_template( "pop_main.html" )
        context={
            }
        return HttpResponse( template.render( context, request ) )
