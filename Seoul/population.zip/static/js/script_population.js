/**
 * 
 */
 
 function locationKindChange(loc) {
	var aaa = ["창덕궁·종묘", "광화문·덕수궁", "경복궁·서촌마을"];
	var bbb = ["서울숲공원", "남산공원", "국립중앙박물관·용산가족공원", "서울대공원", "이촌한강공원", "월드컵공원", "잠실한강공원", "반포한강공원", "잠실한강공원", "뚝섬한강공원", "망원한강공원", "북서울꿈의숲"];
	var ccc = ["종로·청계 관광특구", "이태원 관광특구", "잠실 관광특구", "명동 관광특구", "동대문 관광특구", "강남 MICE 관광특구", "홍대 관광특구"];
	var ddd = ["여의도", "인사동·익선동", "DMC(디지털미디어시티)", "북촌한옥마을", "성수카페거리", "가로수길", "압구정로데오거리", "창동 신경제 중심지", "영등포 타임스퀘어", "노량진", "쌍문동 맛집거리", "수유리 먹자골목", "낙산공원·이화마을" ];
	var eee = ["구로디지털단지역", "선릉역", "서울역", "가산디지털단지역", "역삼역", "강남역", "고속터미널역", "용산역", "교대역", "연신내역", "신촌·이대역", "왕십리역", "신림역", "건대입구역", "신도림역" ];
	
	var target = document.getElementById("locationKindD");	
	
	if(loc.value=="a") var z = aaa;
	else if(loc.value=="b") var z = bbb;
	else if(loc.value=="c") var z = ccc;
	else if(loc.value=="d") var z = ddd;
	else if(loc.value=="e") var z = eee;
	
	target.options.length = 0;
	
	for( x in z ) {
		var opt = document.createElement("option");
		opt.value= z[x];
		opt.innerHTML = z[x];
		target.appendChild(opt);
		
	}
}

$(document).ready(function(){
    pieAct();
})

function pieAct(){
    var color = ["#60D0FD","#ADE7FD","#2F677D","#89B7C9"]; //그래프 색상
    var angel = -90; //그래프 시작 지점
    var pieWidth = $('.pie').width(); 

    $('.pie circle').each(function(i){
        var percentData = $(this).data('percent'); //그래프 비율
        var perimeter = (pieWidth/2) * 3.14; //원의 둘레
        var percent =  percentData*(perimeter/100); //그래프 비율만큼 원의 둘레 계산
        
        //그래프 비율, 색상 설정
        $(this).css({
            'stroke-dasharray':percent+' '+perimeter, 
            'stroke':color[i],
            'transform':'rotate('+angel+'deg)'
        });
        $('.pie_info > li').eq(i).find('.color').css({'background':color[i]});
        
        //그래프 시작 지점 갱신
        angel += (percentData * 3.6); 
    })
}